import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RegisterProfileimgPage } from './register-profileimg';

@NgModule({
  declarations: [
    RegisterProfileimgPage,
  ],
  imports: [
    IonicPageModule.forChild(RegisterProfileimgPage),
  ],
})
export class RegisterProfileimgPageModule {}
